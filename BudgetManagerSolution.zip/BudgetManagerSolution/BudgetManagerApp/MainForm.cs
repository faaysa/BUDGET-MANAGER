﻿using System;
using System.Windows.Forms;
using BudgetHelperLibrary;  // Reference to your DLL

namespace BudgetManagerApp
{
    // Regular public class, NOT partial — since we're not using the Designer
    public class MainForm : Form
    {
        // GUI components
        private TextBox txtName, txtAmount;
        private ComboBox cmbCategory;
        private Label lblTotal;
        private Button btnAdd, btnSummary;

        // Constructor to initialize the form and its controls
        public MainForm()
        {
            // Set the window title and size
            this.Text = "Budget Manager";
            this.Size = new System.Drawing.Size(400, 300);

            // Call method to initialize and place controls
            InitializeComponents();
        }

        // Method to create and add controls to the form
        private void InitializeComponents()
        {
            // Expense Name
            var lblName = new Label() { Text = "Expense Name:", Top = 20, Left = 10 };
            txtName = new TextBox() { Top = 20, Left = 120, Width = 200 };

            // Amount
            var lblAmount = new Label() { Text = "Amount ($):", Top = 60, Left = 10 };
            txtAmount = new TextBox() { Top = 60, Left = 120, Width = 200 };

            // Category Dropdown
            var lblCategory = new Label() { Text = "Category:", Top = 100, Left = 10 };
            cmbCategory = new ComboBox() { Top = 100, Left = 120, Width = 200 };
            cmbCategory.Items.AddRange(new string[] { "Food", "Transport", "Entertainment", "Utilities", "Other" });
            cmbCategory.SelectedIndex = 0;

            // Total Display
            lblTotal = new Label() { Text = "Total: $0.00", Top = 140, Left = 10, Width = 300 };

            // Add Expense Button
            btnAdd = new Button() { Text = "Add Expense", Top = 180, Left = 10 };
            btnAdd.Click += BtnAdd_Click;

            // Show Summary Button
            btnSummary = new Button() { Text = "Show Summary", Top = 180, Left = 150 };
            btnSummary.Click += BtnSummary_Click;

            // Add controls to the form
            this.Controls.Add(lblName);
            this.Controls.Add(txtName);
            this.Controls.Add(lblAmount);
            this.Controls.Add(txtAmount);
            this.Controls.Add(lblCategory);
            this.Controls.Add(cmbCategory);
            this.Controls.Add(lblTotal);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnSummary);
        }

        // Handle the Add button click event
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string category = cmbCategory.SelectedItem.ToString();

            if (double.TryParse(txtAmount.Text, out double amount))
            {
                // Add expense to the list using DLL logic
                BudgetCalculator.AddExpense(name, amount, category);

                // Update total and display
                double total = BudgetCalculator.GetTotal();
                lblTotal.Text = $"Total: ${total:F2}";

                // Alert if over budget
                if (BudgetCalculator.IsOverBudget(1000))
                {
                    MessageBox.Show("⚠️ Over budget: $1000 limit exceeded.", "Budget Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Clear input fields
                txtName.Clear();
                txtAmount.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a valid numeric amount.");
            }
        }

        // Handle the Summary button click event
        private void BtnSummary_Click(object sender, EventArgs e)
        {
            string[] summary = BudgetCalculator.GetExpenseSummary();
            MessageBox.Show(string.Join("\n", summary), "Expense Summary");
        }
    }
}
