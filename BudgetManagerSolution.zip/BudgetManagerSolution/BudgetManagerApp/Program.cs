﻿using System;
using System.Windows.Forms;

namespace BudgetManagerApp
{
    static class Program
    {
        // Main entry point of the application
        [STAThread]
        static void Main()
        {
            // Enable modern UI style
            Application.EnableVisualStyles();

            // Use standard text rendering
            Application.SetCompatibleTextRenderingDefault(false);

            // Launch the custom form MainForm
            Application.Run(new MainForm());
        }
    }
}
