﻿using System;
using System.Collections.Generic;

namespace BudgetHelperLibrary
{
    // Public class to perform budgeting operations
    public class BudgetCalculator
    {
        // List to store expenses: each item holds name, amount, and category
        // This is a reference type
        private static List<(string name, double amount, string category)> expenses = new List<(string, double, string)>();

        // Adds a new expense to the list
        public static void AddExpense(string name, double amount, string category)
        {
            expenses.Add((name, amount, category));
        }

        // Calculates the total of all added expenses
        public static double GetTotal()
        {
            // Variable to hold running total (value type)
            double total = 0;

            // Loop through each expense and add its amount to the total
            foreach (var e in expenses)
            {
                total += e.amount;
            }

            return total;  // Return final sum
        }

        // Checks if total expenses exceed a specified budget
        public static bool IsOverBudget(double budget)
        {
            // Returns true if total is greater than the provided budget
            return GetTotal() > budget;
        }

        // Returns an array of strings summarizing each expense
        public static string[] GetExpenseSummary()
        {
            // Initialize array to match number of expenses (array = value type)
            string[] summary = new string[expenses.Count];

            // Loop to populate the summary array with readable text
            for (int i = 0; i < expenses.Count; i++)
            {
                summary[i] = $"{expenses[i].name} - ${expenses[i].amount:F2} - {expenses[i].category}";
            }

            return summary;  // Return the filled array
        }
    }
}